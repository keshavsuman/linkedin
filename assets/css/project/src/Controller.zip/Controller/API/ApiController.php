<?php
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Event\EventManager;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;
use Cake\Error\Debugger;
use Cake\Http\Exception;

class ApiController extends AppController
{
	function beforeFilter(Event $event) {
	    parent::beforeFilter($event);
         // $this->getEventManager()->off($this->Csrf);
	    $this->viewBuilder()->setLayout(false);
	}
	
    function updateCategory($cat_id){
    	if((int)$cat_id >0){
			$categoryTable = TableRegistry::get('Category');
			$category = $categoryTable->get($cat_id); // Return category with id 
			$category->name = $this->request->getData('name');
			$category->is_active = $this->request->getData('is_active');
			$categoryTable->save($category);
		}
    }

    function getCategoryData(){
    	
		$cat_id = $this->request->getData('category_id','39'); 
		$category = TableRegistry::get('Category');
		$query = $category
	    ->find()
	    ->select(['id','name','children_count'])
	    ->where(['id =' => $cat_id]);
	    foreach ($query as $data) {
	    	$sample[]=$data;
		}   
		$reponse['status'] ="ok";
		$reponse['data'] =$sample;
		$reponse['msg'] ="category list";
		echo json_encode($reponse);
		die;
    }
    function getRootCategory(){
    	$category = TableRegistry::get('Category');
		$query = $category
	    ->find()
	    ->select(['id','children_count','name'])
	    ->order(['name'=>'asc'])
	    ->where(['level ='=>'0']);
	    $simple=[];
	    foreach ($query as $data) {
		   $simple[]=$data;
		}
		$reponse['status'] ="ok";
		$reponse['data'] =$simple;
		$reponse['msg'] ="category list";
		echo json_encode($reponse);
		die;
    }
    function getProductByCategoryId(){
    	$connection = ConnectionManager::get('default');
    	$category_id = $this->request->getData('category_id','39');
    	$sql = "select p.name_en,p.name_hn,p.pic,p.primary_price,p.selling_price from catalog_category_product as c left join catalog_product_entity as p on c.product_id=p.id where c.category_id=$category_id";	
    	$simple = $connection->execute($sql)->fetchAll('assoc');

		$reponse['status'] ="ok";
		$reponse['data'] =$simple;
		$reponse['msg'] ="category list";
		echo json_encode($reponse);
		die;
    }

   
}
